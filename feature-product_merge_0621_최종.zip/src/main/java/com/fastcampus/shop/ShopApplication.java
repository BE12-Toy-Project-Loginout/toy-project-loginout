package com.fastcampus.shop;

import org.springframework.context.annotation.Configuration;

/**
 * Main application class for the Shop application
 */
@Configuration
public class ShopApplication {
    // This class can be used for Java-based configuration if needed
}
