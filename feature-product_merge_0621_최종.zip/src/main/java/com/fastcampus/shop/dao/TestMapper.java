package com.fastcampus.shop.dao;

public interface TestMapper {
    String testConnection();
}
